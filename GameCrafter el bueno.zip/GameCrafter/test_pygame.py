import pygame
import sys

# Inicializar pygame
pygame.init()

# Crear pantalla
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Test Pygame")

# Colores
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Fuente
font = pygame.font.SysFont("Arial", 36)

# Reloj para controlar FPS
clock = pygame.time.Clock()

# Variables para el círculo
circle_x = WIDTH // 2
circle_y = HEIGHT // 2
circle_radius = 50
circle_speed = 5

# Bucle principal
running = True
print("Pygame está corriendo. Deberías ver una ventana con un círculo azul que puedes mover.")
print("Usa las flechas para mover el círculo. Presiona ESC para salir.")

try:
    while running:
        # Manejo de eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    
        # Controles de movimiento
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            circle_x -= circle_speed
        if keys[pygame.K_RIGHT]:
            circle_x += circle_speed
        if keys[pygame.K_UP]:
            circle_y -= circle_speed
        if keys[pygame.K_DOWN]:
            circle_y += circle_speed
            
        # Mantener el círculo dentro de la pantalla
        circle_x = max(circle_radius, min(WIDTH - circle_radius, circle_x))
        circle_y = max(circle_radius, min(HEIGHT - circle_radius, circle_y))
        
        # Limpiar pantalla
        screen.fill(BLACK)
        
        # Dibujar círculo
        pygame.draw.circle(screen, BLUE, (circle_x, circle_y), circle_radius)
        
        # Dibujar borde del círculo
        pygame.draw.circle(screen, WHITE, (circle_x, circle_y), circle_radius, 2)
        
        # Renderizar texto
        text = font.render("Test de Pygame", True, GREEN)
        screen.blit(text, (WIDTH//2 - text.get_width()//2, 50))
        
        instructions = font.render("Usa las flechas para mover", True, WHITE)
        screen.blit(instructions, (WIDTH//2 - instructions.get_width()//2, HEIGHT - 100))
        
        # Actualizar pantalla
        pygame.display.flip()
        
        # Controlar velocidad
        clock.tick(60)
        
except Exception as e:
    print(f"Error: {e}")
finally:
    # Cerrar pygame
    pygame.quit()
    sys.exit()
