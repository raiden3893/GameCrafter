import json
import re
import os
import sys
import random
from datetime import datetime

# Constantes
GAME_DATA_FILE = "game_data.json"

def load_game_data():
    """Carga los datos del juego (usuarios y puntuaciones) desde el archivo JSON"""
    try:
        with open(GAME_DATA_FILE, "r") as f:
            data = json.load(f)
            return data
    except (FileNotFoundError, json.JSONDecodeError):
        # Si el archivo no existe o está corrupto, crear estructura inicial
        default_data = {
            "users": [],
            "scores": []
        }
        save_game_data(default_data)
        return default_data

def save_game_data(data):
    """Guarda los datos del juego en el archivo JSON"""
    with open(GAME_DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

def validate_email(email):
    """Valida que el correo electrónico tenga un formato válido"""
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(pattern, email))

def user_exists(email):
    """Verifica si un usuario ya existe en el sistema"""
    data = load_game_data()
    for user in data["users"]:
        if user["email"] == email:
            return True
    return False

def add_user(email):
    """Añade un nuevo usuario al sistema"""
    if not validate_email(email) or user_exists(email):
        return False
    
    data = load_game_data()
    data["users"].append({
        "email": email,
        "created_at": int(datetime.now().timestamp() * 1000)  # Simulando pygame.time.get_ticks()
    })
    save_game_data(data)
    return True

def save_score(email, score):
    """Guarda la puntuación de un usuario"""
    if not user_exists(email):
        return False
        
    data = load_game_data()
    data["scores"].append({
        "email": email,
        "score": score,
        "date": int(datetime.now().timestamp() * 1000)  # Simulando pygame.time.get_ticks()
    })
    save_game_data(data)
    return True

def get_top_scores(limit=10):
    """Obtiene las mejores puntuaciones ordenadas de mayor a menor"""
    data = load_game_data()
    scores = data["scores"]
    # Ordenar puntuaciones de mayor a menor
    scores.sort(key=lambda x: x["score"], reverse=True)
    # Convertir a lista de tuplas (email, score) para facilitar su uso
    result = [(score["email"], score["score"]) for score in scores[:limit]]
    return result

def print_users():
    """Imprime la lista de usuarios registrados"""
    data = load_game_data()
    print("\n=== USUARIOS REGISTRADOS ===")
    if not data["users"]:
        print("No hay usuarios registrados.")
    else:
        for i, user in enumerate(data["users"], 1):
            print(f"{i}. {user['email']}")

def print_scores():
    """Imprime la tabla de puntuaciones"""
    scores = get_top_scores()
    print("\n=== MEJORES PUNTUACIONES ===")
    if not scores:
        print("No hay puntuaciones registradas.")
    else:
        for i, (email, score) in enumerate(scores, 1):
            print(f"{i}. {email}: {score} puntos")

def login_user():
    """Función para iniciar sesión con email"""
    print("\n=== INICIAR SESIÓN ===")
    email = input("Ingresa tu correo electrónico: ")
    
    if not validate_email(email):
        print("Error: El formato del correo electrónico no es válido.")
        return None
    
    if not user_exists(email):
        print(f"El usuario {email} no existe. Registrándolo...")
        if add_user(email):
            print(f"Usuario {email} registrado correctamente.")
        else:
            print("Error al registrar el usuario.")
            return None
    
    print(f"Sesión iniciada como {email}")
    return email

def simulate_game(email):
    """Simula una partida y guarda la puntuación"""
    print("\n=== INICIANDO PARTIDA ===")
    print("Controles: Usa WASD para mover la nave (simulado)")
    print("          Espacio para disparar (simulado)")
    
    player_health = 100
    player_lives = 3
    player_score = 0
    enemies_killed = 0
    boss_appeared = False
    boss_health = 500
    game_over = False
    victory = False
    
    while not game_over and not victory:
        print("\n" + "="*50)
        print(f"Salud: {player_health} | Vidas: {player_lives} | Puntuación: {player_score}")
        print(f"Enemigos eliminados: {enemies_killed}")
        
        if boss_appeared:
            print(f"JEFE: Salud: {boss_health}/500")
        
        print("\n¿Qué quieres hacer?")
        print("1. Moverse y esquivar")
        print("2. Disparar a los enemigos")
        if boss_appeared:
            print("3. Disparar al jefe")
        print("9. Rendirse")
        
        choice = input("Tu acción: ")
        
        # Procesar acción del jugador
        if choice == "1":
            print("Te mueves para esquivar los disparos enemigos...")
            # Posibilidad de recibir daño
            if random.random() < 0.3:  # 30% de probabilidad de recibir daño
                damage = random.randint(5, 15)
                player_health -= damage
                print(f"¡Te han alcanzado! Has perdido {damage} de salud.")
            else:
                print("¡Has esquivado todos los disparos!")
        
        elif choice == "2":
            print("¡Disparas a las naves enemigas!")
            if random.random() < 0.7:  # 70% de probabilidad de acertar
                enemies_hit = random.randint(1, 3)
                enemies_killed += enemies_hit
                points = enemies_hit * 100
                player_score += points
                print(f"¡Has destruido {enemies_hit} naves enemigas! +{points} puntos")
            else:
                print("Tus disparos han fallado...")
        
        elif choice == "3" and boss_appeared:
            print("¡Disparas al jefe!")
            if random.random() < 0.6:  # 60% de probabilidad de acertar
                damage = random.randint(20, 50)
                boss_health -= damage
                print(f"¡Has dañado al jefe! -{damage} de salud")
                
                if boss_health <= 0:
                    print("¡Has derrotado al jefe!")
                    player_score += 1000
                    victory = True
            else:
                print("Tus disparos han fallado...")
        
        elif choice == "9":
            print("Te has rendido...")
            game_over = True
            continue
        
        else:
            print("Acción no válida. Has perdido tu turno.")
        
        # Verificar si aparece el jefe
        if not boss_appeared and enemies_killed >= 5:  # Reducido a 5 enemigos para que aparezca más rápido
            boss_appeared = True
            print("\n¡ALERTA! ¡EL JEFE HA APARECIDO!")
        
        # Ataques enemigos
        if not game_over and not victory:
            print("\nLos enemigos contraatacan...")
            if random.random() < 0.5:  # 50% de probabilidad de recibir daño
                if boss_appeared:
                    damage = random.randint(10, 30)  # Más daño si el jefe está presente
                else:
                    damage = random.randint(5, 15)
                    
                player_health -= damage
                print(f"¡Te han alcanzado! Has perdido {damage} de salud.")
            else:
                print("¡Has evitado todos los ataques enemigos!")
            
        # Verificar estado de salud
        if player_health <= 0:
            player_lives -= 1
            print(f"\n¡Has perdido una vida! Te quedan {player_lives} vidas.")
            
            if player_lives > 0:
                player_health = 100
                print("¡Nave regenerada! Salud restaurada a 100.")
            else:
                print("\n¡GAME OVER! Te has quedado sin vidas.")
                game_over = True
    
    # Fin del juego
    if victory:
        print("\n¡¡¡VICTORIA!!!")
        print(f"Has completado el juego con {player_score} puntos.")
    else:
        print("\nFin de la partida.")
        print(f"Puntuación final: {player_score}")
    
    # Guardar puntuación
    if save_score(email, player_score):
        print("Puntuación guardada correctamente.")
    else:
        print("Error al guardar la puntuación.")
    
    return player_score

def main_menu():
    """Muestra el menú principal"""
    current_user = None
    
    while True:
        print("\n=== SPACE SHOOTER - MENÚ PRINCIPAL ===")
        print("1. Iniciar sesión")
        print("2. Ver usuarios registrados")
        print("3. Ver tabla de puntuaciones")
        if current_user:
            print(f"4. Jugar como {current_user}")
        print("0. Salir")
        
        option = input("\nSelecciona una opción: ")
        
        if option == "1":
            current_user = login_user()
        elif option == "2":
            print_users()
        elif option == "3":
            print_scores()
        elif option == "4" and current_user:
            simulate_game(current_user)
        elif option == "0":
            print("¡Gracias por jugar! Hasta pronto.")
            break
        else:
            print("Opción no válida.")

if __name__ == "__main__":
    print("Bienvenido al simulador de Space Shooter")
    main_menu()